<?

    /***********************************************************************
     * constants.php
     *
     * CC50
     * Pset 7
     *
     * Constantes globais
     **********************************************************************/


    // o nome do seu banco de dados
    define("DB_NAME", "finance");

    // o administrador do seu banco de dados
    define("DB_USER", "root");

    // a senha do seu banco de dados
    define("DB_PASS", "");

    // o servidor onde o seu banco de dados está hospedado
    define("DB_SERVER", "localhost");

    // URL do Yahoo Finanças
    define("YAHOO", "http://download.finance.yahoo.com/d/quotes.csv?f=snl1d1t1c1ohg&s=");

?>
