<?

    // require common code
    require_once("includes/common.php"); 

    // log out current user, if any
    logout();

?>

<!DOCTYPE html>

<html>

  <head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
    <link href="css/styles.css" rel="stylesheet" type="text/css">
    <title>CC50 Finanças: Log out</title>
  </head>

  <body>

    <div id="top">
      <a href="index.php"><img alt="CC50 Finanças" src="images/logo.png" style="height: 200px;"></a>
    </div>

    <div id="middle">
      kthxbai
    </div>

    <div id="bottom">
      faça o <a href="login.php">login</a> de novo
    </div>

  </body>

</html>
