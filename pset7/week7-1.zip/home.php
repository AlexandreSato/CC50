<!DOCTYPE HTML>

<html>
  <head>
    <title>Hello World</title>
  </head>
  
  <body>
    <? for ($i = 0; $i < 10; $i++) { ?>
    <img src='images/hamster1.jpg'> 
    <? } ?>
  </body>
</html>
